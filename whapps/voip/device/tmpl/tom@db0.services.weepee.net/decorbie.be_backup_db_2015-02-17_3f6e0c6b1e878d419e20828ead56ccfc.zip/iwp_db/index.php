<?php
			global $old_url, $old_file_path;
			$old_url = 'http://www.decorbie.be';
			$old_file_path = '/var/www/html/decorbie.be/public_html/';
			