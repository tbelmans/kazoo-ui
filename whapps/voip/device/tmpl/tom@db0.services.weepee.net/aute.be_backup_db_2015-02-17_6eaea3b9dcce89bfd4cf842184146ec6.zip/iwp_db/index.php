<?php
			global $old_url, $old_file_path;
			$old_url = 'http://aute.be';
			$old_file_path = '/var/www/html/aute.be/public_html/';
			