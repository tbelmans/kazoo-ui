<?php
			global $old_url, $old_file_path;
			$old_url = 'http://uglywood.foonkyfish.be';
			$old_file_path = '/var/www/html/uglywood.foonkyfish.be/public_html/';
			