<?php
			global $old_url, $old_file_path;
			$old_url = 'http://antwerpenaikikai.be';
			$old_file_path = '/var/www/html/antwerpenaikikai.be/public_html/';
			