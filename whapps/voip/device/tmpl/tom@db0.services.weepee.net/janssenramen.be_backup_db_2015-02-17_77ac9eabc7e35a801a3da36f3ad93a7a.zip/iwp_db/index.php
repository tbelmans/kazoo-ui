<?php
			global $old_url, $old_file_path;
			$old_url = 'http://janssenramen.be';
			$old_file_path = '/var/www/html/janssenramen.be/public_html/';
			