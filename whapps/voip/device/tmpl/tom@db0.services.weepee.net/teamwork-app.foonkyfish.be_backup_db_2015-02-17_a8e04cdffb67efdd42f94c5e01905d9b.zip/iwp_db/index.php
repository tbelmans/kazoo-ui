<?php
			global $old_url, $old_file_path;
			$old_url = 'http://teamwork-app.foonkyfish.be';
			$old_file_path = '/var/www/html/teamwork-app.foonkyfish.be/public_html/';
			