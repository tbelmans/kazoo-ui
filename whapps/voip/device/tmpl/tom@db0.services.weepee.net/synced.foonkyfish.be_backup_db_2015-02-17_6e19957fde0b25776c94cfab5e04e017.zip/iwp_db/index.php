<?php
			global $old_url, $old_file_path;
			$old_url = 'http://synced.foonkyfish.be';
			$old_file_path = '/var/www/html/synced.foonkyfish.be/public_html/';
			