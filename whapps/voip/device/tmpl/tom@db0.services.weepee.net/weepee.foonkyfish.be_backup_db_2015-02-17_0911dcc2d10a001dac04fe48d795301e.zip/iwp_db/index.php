<?php
			global $old_url, $old_file_path;
			$old_url = 'http://weepee.foonkyfish.be';
			$old_file_path = '/var/www/html/weepee.foonkyfish.be/public_html/';
			