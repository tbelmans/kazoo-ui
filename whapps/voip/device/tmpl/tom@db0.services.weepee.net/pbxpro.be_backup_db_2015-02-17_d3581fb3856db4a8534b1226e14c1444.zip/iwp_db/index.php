<?php
			global $old_url, $old_file_path;
			$old_url = 'http://pbxpro.be';
			$old_file_path = '/var/www/html/pbxpro.be/public_html/';
			