<?php
			global $old_url, $old_file_path;
			$old_url = 'http://betonnejeugd.be';
			$old_file_path = '/var/www/html/betonnejeugd.be/public_html/';
			