<?php
			global $old_url, $old_file_path;
			$old_url = 'http://interteltelecom.com';
			$old_file_path = '/var/www/html/interteltelecom.com/public_html/';
			