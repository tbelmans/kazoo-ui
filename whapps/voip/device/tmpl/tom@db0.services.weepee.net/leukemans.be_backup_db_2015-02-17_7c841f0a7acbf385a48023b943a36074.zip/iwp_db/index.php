<?php
			global $old_url, $old_file_path;
			$old_url = 'http://leukemans.be';
			$old_file_path = '/var/www/html/leukemans.be/public_html/';
			