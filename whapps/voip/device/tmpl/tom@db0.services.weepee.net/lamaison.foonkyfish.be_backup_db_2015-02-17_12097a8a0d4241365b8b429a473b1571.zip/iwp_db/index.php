<?php
			global $old_url, $old_file_path;
			$old_url = 'http://lamaison.foonkyfish.be';
			$old_file_path = '/var/www/html/lamaisondupontvieux.com/public_html/';
			