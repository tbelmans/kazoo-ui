<?php
			global $old_url, $old_file_path;
			$old_url = 'http://urban-a.eu';
			$old_file_path = '/var/www/html/gafpa.com/domains/urban-a.eu/public_html/';
			