<?php
			global $old_url, $old_file_path;
			$old_url = 'http://labworx.tv';
			$old_file_path = '/var/www/html/labworx.tv/public_html/';
			