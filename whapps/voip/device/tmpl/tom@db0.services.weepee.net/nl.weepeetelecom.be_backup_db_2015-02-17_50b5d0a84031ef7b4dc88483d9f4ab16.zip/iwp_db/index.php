<?php
			global $old_url, $old_file_path;
			$old_url = 'http://nl.weepeetelecom.be';
			$old_file_path = '/var/www/html/';
			