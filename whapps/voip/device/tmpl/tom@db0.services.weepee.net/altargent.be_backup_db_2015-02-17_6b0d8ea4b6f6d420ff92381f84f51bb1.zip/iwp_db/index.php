<?php
			global $old_url, $old_file_path;
			$old_url = 'http://altargent.be';
			$old_file_path = '/data/sites/web/altargentbe/www/';
			