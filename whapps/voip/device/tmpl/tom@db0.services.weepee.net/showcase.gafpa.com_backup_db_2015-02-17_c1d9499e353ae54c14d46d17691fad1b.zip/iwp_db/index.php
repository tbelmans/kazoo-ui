<?php
			global $old_url, $old_file_path;
			$old_url = 'http://showcase.gafpa.com';
			$old_file_path = '/var/www/html/gafpa.com/domains/showcase.gafpa.com/public_html/';
			