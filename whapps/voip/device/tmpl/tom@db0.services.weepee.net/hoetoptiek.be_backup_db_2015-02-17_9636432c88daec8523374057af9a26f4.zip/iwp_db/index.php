<?php
			global $old_url, $old_file_path;
			$old_url = 'http://hoetoptiek.be';
			$old_file_path = '/var/www/html/hoetoptiek.be/public_html/';
			