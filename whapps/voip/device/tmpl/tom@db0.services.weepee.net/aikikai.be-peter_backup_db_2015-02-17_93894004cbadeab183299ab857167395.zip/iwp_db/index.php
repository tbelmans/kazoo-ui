<?php
			global $old_url, $old_file_path;
			$old_url = 'http://aikikai.be/peter/wp';
			$old_file_path = '/var/www/html/antwerpenaikikai.be/public_html/peter/wp/';
			