<?php
			global $old_url, $old_file_path;
			$old_url = 'http://intra.weepee.net';
			$old_file_path = '/var/www/html/intra.weepee.net/public_html/';
			